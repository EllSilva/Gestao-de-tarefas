const com = {
    data: function () {
        return {
          text: 0
        }
      },
      template: ''
}

export default com